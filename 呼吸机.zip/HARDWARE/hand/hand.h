#ifndef __DLVR_H
#define __DLVR_H


void hand_Init();
void hand_control();














#endif